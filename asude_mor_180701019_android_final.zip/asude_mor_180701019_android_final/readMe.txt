Asude MOR
180701019
Yazılım Mühendisliği
3. Sınıf.

Search yaparken title ları ekleyemedim.
Onun dışındaki her şey çalışıyor.
